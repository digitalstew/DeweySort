﻿namespace DeweySort_v1._0
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listView1 = new System.Windows.Forms.ListView();
            this.cmdLoadRandom50 = new System.Windows.Forms.Button();
            this.cmdLoadRandom75 = new System.Windows.Forms.Button();
            this.cmdStartTiming = new System.Windows.Forms.Button();
            this.cmdStopTiming = new System.Windows.Forms.Button();
            this.cmdLoadRandom100 = new System.Windows.Forms.Button();
            this.cmdCheckResults = new System.Windows.Forms.Button();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.cmdFont = new System.Windows.Forms.Button();
            this.cmdResetTiming = new System.Windows.Forms.Button();
            this.chkShowTimer = new System.Windows.Forms.CheckBox();
            this.optRangeNarrow = new System.Windows.Forms.RadioButton();
            this.optRangeWide = new System.Windows.Forms.RadioButton();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblTimer = new System.Windows.Forms.Label();
            this.cmdClearList = new System.Windows.Forms.Button();
            this.cmdShuffleCurrentList = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblFontSize = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmdLoadRandom10 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cmdShowErrors = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblItemCount = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.Location = new System.Drawing.Point(162, 23);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(757, 460);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.List;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // cmdLoadRandom50
            // 
            this.cmdLoadRandom50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdLoadRandom50.Location = new System.Drawing.Point(15, 73);
            this.cmdLoadRandom50.Name = "cmdLoadRandom50";
            this.cmdLoadRandom50.Size = new System.Drawing.Size(108, 36);
            this.cmdLoadRandom50.TabIndex = 1;
            this.cmdLoadRandom50.Text = "Random 50";
            this.cmdLoadRandom50.UseVisualStyleBackColor = true;
            this.cmdLoadRandom50.Click += new System.EventHandler(this.cmdLoadRandom50_Click);
            // 
            // cmdLoadRandom75
            // 
            this.cmdLoadRandom75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdLoadRandom75.Location = new System.Drawing.Point(15, 117);
            this.cmdLoadRandom75.Name = "cmdLoadRandom75";
            this.cmdLoadRandom75.Size = new System.Drawing.Size(108, 36);
            this.cmdLoadRandom75.TabIndex = 2;
            this.cmdLoadRandom75.Text = "Random 75";
            this.cmdLoadRandom75.UseVisualStyleBackColor = true;
            this.cmdLoadRandom75.Click += new System.EventHandler(this.cmdLoadRandom75_Click);
            // 
            // cmdStartTiming
            // 
            this.cmdStartTiming.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdStartTiming.Location = new System.Drawing.Point(14, 29);
            this.cmdStartTiming.Name = "cmdStartTiming";
            this.cmdStartTiming.Size = new System.Drawing.Size(108, 36);
            this.cmdStartTiming.TabIndex = 3;
            this.cmdStartTiming.Text = "Start";
            this.cmdStartTiming.UseVisualStyleBackColor = true;
            this.cmdStartTiming.Click += new System.EventHandler(this.cmdStartTiming_Click);
            // 
            // cmdStopTiming
            // 
            this.cmdStopTiming.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdStopTiming.Location = new System.Drawing.Point(14, 73);
            this.cmdStopTiming.Name = "cmdStopTiming";
            this.cmdStopTiming.Size = new System.Drawing.Size(108, 36);
            this.cmdStopTiming.TabIndex = 4;
            this.cmdStopTiming.Text = "Stop";
            this.cmdStopTiming.UseVisualStyleBackColor = true;
            this.cmdStopTiming.Click += new System.EventHandler(this.cmdStopTiming_Click);
            // 
            // cmdLoadRandom100
            // 
            this.cmdLoadRandom100.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdLoadRandom100.Location = new System.Drawing.Point(15, 161);
            this.cmdLoadRandom100.Name = "cmdLoadRandom100";
            this.cmdLoadRandom100.Size = new System.Drawing.Size(108, 36);
            this.cmdLoadRandom100.TabIndex = 5;
            this.cmdLoadRandom100.Text = "Random 100";
            this.cmdLoadRandom100.UseVisualStyleBackColor = true;
            this.cmdLoadRandom100.Click += new System.EventHandler(this.cmdLoadRandom100_Click);
            // 
            // cmdCheckResults
            // 
            this.cmdCheckResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdCheckResults.Location = new System.Drawing.Point(937, 23);
            this.cmdCheckResults.Name = "cmdCheckResults";
            this.cmdCheckResults.Size = new System.Drawing.Size(138, 38);
            this.cmdCheckResults.TabIndex = 6;
            this.cmdCheckResults.Text = "Check Results";
            this.cmdCheckResults.UseVisualStyleBackColor = true;
            this.cmdCheckResults.Click += new System.EventHandler(this.cmdCheckResults_Click);
            this.cmdCheckResults.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cmdCheckResults_MouseDown);
            // 
            // txtStatus
            // 
            this.txtStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus.Location = new System.Drawing.Point(937, 71);
            this.txtStatus.Multiline = true;
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(138, 150);
            this.txtStatus.TabIndex = 9;
            // 
            // cmdFont
            // 
            this.cmdFont.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdFont.Location = new System.Drawing.Point(14, 73);
            this.cmdFont.Name = "cmdFont";
            this.cmdFont.Size = new System.Drawing.Size(108, 36);
            this.cmdFont.TabIndex = 10;
            this.cmdFont.Text = "Font";
            this.cmdFont.UseVisualStyleBackColor = true;
            this.cmdFont.Click += new System.EventHandler(this.cmdFont_Click);
            // 
            // cmdResetTiming
            // 
            this.cmdResetTiming.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdResetTiming.Location = new System.Drawing.Point(14, 117);
            this.cmdResetTiming.Name = "cmdResetTiming";
            this.cmdResetTiming.Size = new System.Drawing.Size(108, 36);
            this.cmdResetTiming.TabIndex = 11;
            this.cmdResetTiming.Text = "Reset";
            this.cmdResetTiming.UseVisualStyleBackColor = true;
            this.cmdResetTiming.Click += new System.EventHandler(this.cmdReset_Click);
            // 
            // chkShowTimer
            // 
            this.chkShowTimer.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkShowTimer.Checked = true;
            this.chkShowTimer.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowTimer.Location = new System.Drawing.Point(14, 198);
            this.chkShowTimer.Name = "chkShowTimer";
            this.chkShowTimer.Size = new System.Drawing.Size(108, 36);
            this.chkShowTimer.TabIndex = 12;
            this.chkShowTimer.Text = "Show";
            this.chkShowTimer.UseVisualStyleBackColor = true;
            this.chkShowTimer.CheckedChanged += new System.EventHandler(this.chkShowTimer_CheckedChanged);
            // 
            // optRangeNarrow
            // 
            this.optRangeNarrow.AutoSize = true;
            this.optRangeNarrow.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optRangeNarrow.Location = new System.Drawing.Point(15, 59);
            this.optRangeNarrow.Name = "optRangeNarrow";
            this.optRangeNarrow.Size = new System.Drawing.Size(84, 24);
            this.optRangeNarrow.TabIndex = 13;
            this.optRangeNarrow.Text = "Narrow";
            this.optRangeNarrow.UseVisualStyleBackColor = true;
            // 
            // optRangeWide
            // 
            this.optRangeWide.AutoSize = true;
            this.optRangeWide.Checked = true;
            this.optRangeWide.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optRangeWide.Location = new System.Drawing.Point(15, 29);
            this.optRangeWide.Name = "optRangeWide";
            this.optRangeWide.Size = new System.Drawing.Size(68, 24);
            this.optRangeWide.TabIndex = 14;
            this.optRangeWide.TabStop = true;
            this.optRangeWide.Text = "Wide";
            this.optRangeWide.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblTimer
            // 
            this.lblTimer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.Location = new System.Drawing.Point(14, 165);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(108, 36);
            this.lblTimer.TabIndex = 16;
            this.lblTimer.Text = "00:00:00";
            this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmdClearList
            // 
            this.cmdClearList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdClearList.Location = new System.Drawing.Point(795, 494);
            this.cmdClearList.Name = "cmdClearList";
            this.cmdClearList.Size = new System.Drawing.Size(109, 36);
            this.cmdClearList.TabIndex = 17;
            this.cmdClearList.Text = "Clear List";
            this.cmdClearList.UseVisualStyleBackColor = true;
            this.cmdClearList.Click += new System.EventHandler(this.cmdClearList_Click);
            // 
            // cmdShuffleCurrentList
            // 
            this.cmdShuffleCurrentList.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdShuffleCurrentList.Location = new System.Drawing.Point(177, 494);
            this.cmdShuffleCurrentList.Name = "cmdShuffleCurrentList";
            this.cmdShuffleCurrentList.Size = new System.Drawing.Size(108, 36);
            this.cmdShuffleCurrentList.TabIndex = 18;
            this.cmdShuffleCurrentList.Text = "Shuffle List";
            this.cmdShuffleCurrentList.UseVisualStyleBackColor = true;
            this.cmdShuffleCurrentList.Click += new System.EventHandler(this.cmdShuffleCurrentList_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(352, 497);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(376, 33);
            this.lblStatus.TabIndex = 20;
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFontSize
            // 
            this.lblFontSize.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFontSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFontSize.Location = new System.Drawing.Point(14, 125);
            this.lblFontSize.Name = "lblFontSize";
            this.lblFontSize.Size = new System.Drawing.Size(108, 32);
            this.lblFontSize.TabIndex = 21;
            this.lblFontSize.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmdLoadRandom10);
            this.groupBox1.Controls.Add(this.cmdLoadRandom50);
            this.groupBox1.Controls.Add(this.cmdLoadRandom75);
            this.groupBox1.Controls.Add(this.cmdLoadRandom100);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(136, 213);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Load";
            // 
            // cmdLoadRandom10
            // 
            this.cmdLoadRandom10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdLoadRandom10.Location = new System.Drawing.Point(15, 29);
            this.cmdLoadRandom10.Name = "cmdLoadRandom10";
            this.cmdLoadRandom10.Size = new System.Drawing.Size(108, 36);
            this.cmdLoadRandom10.TabIndex = 23;
            this.cmdLoadRandom10.Text = "Random 10";
            this.cmdLoadRandom10.UseVisualStyleBackColor = true;
            this.cmdLoadRandom10.Click += new System.EventHandler(this.cmdLoadRandom10_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.optRangeWide);
            this.groupBox2.Controls.Add(this.optRangeNarrow);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 240);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(136, 100);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Range";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmdStartTiming);
            this.groupBox3.Controls.Add(this.cmdStopTiming);
            this.groupBox3.Controls.Add(this.cmdResetTiming);
            this.groupBox3.Controls.Add(this.lblTimer);
            this.groupBox3.Controls.Add(this.chkShowTimer);
            this.groupBox3.Location = new System.Drawing.Point(939, 312);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(138, 243);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Timer";
            // 
            // cmdShowErrors
            // 
            this.cmdShowErrors.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdShowErrors.Location = new System.Drawing.Point(939, 233);
            this.cmdShowErrors.Name = "cmdShowErrors";
            this.cmdShowErrors.Size = new System.Drawing.Size(136, 36);
            this.cmdShowErrors.TabIndex = 25;
            this.cmdShowErrors.Text = "Show Errors";
            this.cmdShowErrors.UseVisualStyleBackColor = true;
            this.cmdShowErrors.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cmdShowErrors_MouseDown);
            this.cmdShowErrors.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cmdShowErrors_MouseUp);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblItemCount);
            this.groupBox4.Controls.Add(this.cmdFont);
            this.groupBox4.Controls.Add(this.lblFontSize);
            this.groupBox4.Location = new System.Drawing.Point(13, 356);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(135, 199);
            this.groupBox4.TabIndex = 27;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Item List";
            // 
            // lblItemCount
            // 
            this.lblItemCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblItemCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemCount.Location = new System.Drawing.Point(13, 28);
            this.lblItemCount.Name = "lblItemCount";
            this.lblItemCount.Size = new System.Drawing.Size(108, 32);
            this.lblItemCount.TabIndex = 22;
            this.lblItemCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1089, 567);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.cmdShowErrors);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmdShuffleCurrentList);
            this.Controls.Add(this.cmdClearList);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.cmdCheckResults);
            this.Controls.Add(this.listView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dewey Sort v1.0";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button cmdLoadRandom50;
        private System.Windows.Forms.Button cmdLoadRandom75;
        private System.Windows.Forms.Button cmdStartTiming;
        private System.Windows.Forms.Button cmdStopTiming;
        private System.Windows.Forms.Button cmdLoadRandom100;
        private System.Windows.Forms.Button cmdCheckResults;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Button cmdFont;
        private System.Windows.Forms.Button cmdResetTiming;
        private System.Windows.Forms.CheckBox chkShowTimer;
        private System.Windows.Forms.RadioButton optRangeNarrow;
        private System.Windows.Forms.RadioButton optRangeWide;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Button cmdClearList;
        private System.Windows.Forms.Button cmdShuffleCurrentList;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblFontSize;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button cmdLoadRandom10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button cmdShowErrors;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lblItemCount;
    }
}

